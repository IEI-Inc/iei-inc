-- IEI Cynessa Bootloader v1.0
-- Finds cynessa.lua and launches it with the disk image

local KERNEL = "cynessa.lua"
local DISK   = "cynessa.cyd"

io.write("\n")
io.write("  IEI Inc. StarexBIOS v2.0\n")
io.write("  Cynessa Bootloader v1.0\n")
io.write("  ========================\n\n")

-- Check kernel exists
local kf = io.open(KERNEL, "r")
if not kf then
  io.write("BOOT ERROR: kernel not found: " .. KERNEL .. "\n")
  os.exit(1)
end
kf:close()

-- Check disk image
local df = io.open(DISK, "r")
if not df then
  io.write("BOOT ERROR: disk image not found: " .. DISK .. "\n")
  os.exit(1)
end
df:close()

io.write("  [OK] Kernel: " .. KERNEL .. "\n")
io.write("  [OK] Disk:   " .. DISK .. "\n")
io.write("\n  Handing control to Cynessa...\n\n")
io.flush()

-- Load and execute kernel
local fn, err = loadfile(KERNEL)
if not fn then
  io.write("BOOT ERROR: failed to load kernel: " .. tostring(err) .. "\n")
  os.exit(1)
end

-- Pass disk path via global
CYNESSA_DISK = DISK
CYNESSA_HOSTDISK = os.getenv("HOME") .. "/disk"

fn()
