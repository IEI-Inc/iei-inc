-- mkdisk.lua - IEI Cynessa disk image builder
-- Usage: lua mkdisk.lua <source_dir> <output.cyd>
-- Format: header lines "SECTOR <start> <end> <path>", then END_HEADER, then raw data blob

local src = arg[1] or "disk"
local out = arg[2] or "cynessa.cyd"

local entries = {}
local blobs   = {}
local offset  = 0

local function scan(dir, prefix)
  prefix = prefix or ""
  local p = io.popen("find " .. dir .. " -type f | sort")
  for path in p:lines() do
    local rel = path:sub(#dir + 2)  -- strip src dir prefix
    local f = io.open(path, "rb")
    local data = f:read("*a")
    f:close()
    local len = #data
    table.insert(entries, {vpath="/"..rel, start=offset, stop=offset+len-1})
    table.insert(blobs, data)
    offset = offset + len
  end
  p:close()
end

scan(src)

local f = io.open(out, "wb")
-- Write header
for _, e in ipairs(entries) do
  f:write(string.format("SECTOR %d %d %s\n", e.start, e.stop, e.vpath))
end
f:write("END_HEADER\n")
-- Write data blob
for _, b in ipairs(blobs) do
  f:write(b)
end
f:close()

print(string.format("wrote %s: %d files, %d bytes data", out, #entries, offset))
