-- Cynessa Microkernel v1.0
-- IEI Inc. (c) 2026

io.write("[Cynessa] Kernel starting...\n")

-- ── VFS ───────────────────────────────────────────────────────────────────────
local vfs = {}   -- path -> {data=string, host_path=string or nil}
local hostdisk_path = nil  -- set during boot

local function vfs_mount_disk(disk_path)
  io.write("[Cynessa] Mounting ramdisk: " .. disk_path .. "\n")
  local f = io.open(disk_path, "rb")
  if not f then error("Cannot open disk: " .. disk_path) end

  -- Parse header
  local entries = {}
  local data_offset_in_file = 0
  local byte_count = 0
  while true do
    local line = f:read("*l")
    if not line then error("Malformed disk: no END_HEADER") end
    byte_count = byte_count + #line + 1  -- +1 for newline
    if line == "END_HEADER" then
      data_offset_in_file = byte_count
      break
    end
    local s, e, path = line:match("^SECTOR (%d+) (%d+) (.+)$")
    if s then
      table.insert(entries, {start=tonumber(s), stop=tonumber(e), path=path})
    end
  end

  -- Read full data blob
  local blob = f:read("*a")
  f:close()

  io.write(string.format("[Cynessa] Ramdisk: %d files\n", #entries))

  for _, e in ipairs(entries) do
    local s = e.start + 1  -- Lua 1-indexed
    local en = e.stop + 1
    local data = blob:sub(s, en)
    vfs[e.path] = {data=data}
    io.write(string.format("[Cynessa]   loaded %s (%d bytes)\n", e.path, #data))
  end
end

local function vfs_mount_host(host_path, virt_prefix)
  -- Mount a host directory as a vfs subtree
  io.write("[Cynessa] Mounting host dir: " .. host_path .. " -> " .. virt_prefix .. "\n")
  local p = io.popen("find " .. host_path .. " -type f 2>/dev/null | sort")
  if not p then return end
  for path in p:lines() do
    local rel = path:sub(#host_path + 1)
    local vpath = virt_prefix .. rel
    vfs[vpath] = {host_path=path}
    io.write(string.format("[Cynessa]   mapped %s\n", vpath))
  end
  p:close()
end

local function vfs_read(path)
  -- Host disk takes priority over ramdisk
  if hostdisk_path then
    local hp = hostdisk_path .. path
    local f = io.open(hp, "rb")
    if f then
      local d = f:read("*a"); f:close()
      return d
    end
  end
  -- Fall back to ramdisk
  local node = vfs[path]
  if not node then return nil, "no such file: " .. path end
  if node.data then return node.data end
  if node.host_path then
    local f = io.open(node.host_path, "rb")
    if not f then return nil, "host file unreadable: " .. node.host_path end
    local d = f:read("*a"); f:close()
    return d
  end
  return nil, "empty node"
end

local function vfs_write(path, data)
  if hostdisk_path then
    -- Write to host disk, creating dirs as needed
    local hp = hostdisk_path .. path
    local dir = hp:match("^(.+)/[^/]+$")
    if dir then os.execute("mkdir -p '" .. dir .. "'") end
    local f = io.open(hp, "wb")
    if not f then return false, "cannot write to host disk: " .. hp end
    f:write(data); f:close()
    return true
  end
  -- No host disk: write to ramdisk only
  vfs[path] = {data=data}
  return true
end

local function vfs_ls(prefix)
  local results = {}
  local seen = {}

  -- List from host disk first
  if hostdisk_path then
    local hp = hostdisk_path .. prefix
    local p = io.popen("ls -1 '" .. hp .. "' 2>/dev/null")
    if p then
      for name in p:lines() do
        if not seen[name] then
          seen[name] = true
          table.insert(results, name)
        end
      end
      p:close()
    end
  end

  -- Merge ramdisk entries
  for path in pairs(vfs) do
    if path:sub(1, #prefix) == prefix then
      local rest = path:sub(#prefix + 1)
      local name = rest:match("^/?([^/]+)")
      if name and not seen[name] then
        seen[name] = true
        table.insert(results, name)
      end
    end
  end

  table.sort(results)
  return results
end

-- ── Process table ─────────────────────────────────────────────────────────────
local procs = {}
local next_pid = 1

local function proc_spawn(name, fn)
  local pid = next_pid
  next_pid = next_pid + 1
  procs[pid] = {
    pid    = pid,
    name   = name,
    state  = "ready",  -- ready | running | blocked | zombie
    fn     = fn,
    thread = coroutine.create(fn),
    exit_code = nil,
  }
  io.write(string.format("[Cynessa] spawn pid=%d name=%s\n", pid, name))
  return pid
end

local function proc_exit(pid, code)
  local p = procs[pid]
  if p then
    p.state = "zombie"
    p.exit_code = code or 0
    io.write(string.format("[Cynessa] pid=%d exited code=%d\n", pid, code or 0))
  end
end

-- ── IPC message queues ────────────────────────────────────────────────────────
local mqueues = {}  -- pid -> {msg, ...}

local function ipc_send(to_pid, msg)
  mqueues[to_pid] = mqueues[to_pid] or {}
  table.insert(mqueues[to_pid], msg)
end

local function ipc_recv(pid)
  local q = mqueues[pid]
  if q and #q > 0 then
    return table.remove(q, 1)
  end
  return nil
end

-- ── Syscall interface ─────────────────────────────────────────────────────────
local current_pid = nil

local syscalls = {}

syscalls.read  = function(path)       return vfs_read(path) end
syscalls.write = function(path, data) return vfs_write(path, data) end
syscalls.ls    = function(path)       return vfs_ls(path) end
syscalls.spawn = function(name, fn)   return proc_spawn(name, fn) end
syscalls.exit  = function(code)       proc_exit(current_pid, code) end
syscalls.send  = function(pid, msg)   ipc_send(pid, msg) end
syscalls.recv  = function()           return ipc_recv(current_pid) end
syscalls.getpid= function()           return current_pid end
syscalls.exec  = function(cmd)
  -- Run a host OS command through the kernel, returns exit code
  io.write(string.format("[Cynessa] exec pid=%s: %s\n", tostring(current_pid), cmd))
  local ret = os.execute(cmd)
  return ret
end

local env_table = {}  -- simple environment store

syscalls.getenv = function(key)
  return env_table[key] or os.getenv(key)
end

syscalls.setenv = function(key, val)
  env_table[key] = val
end

syscalls.kill  = function(name)
  local count = 0
  for pid, p in pairs(procs) do
    if p.name == name and p.state ~= "zombie" then
      proc_exit(pid, 1)
      count = count + 1
    end
  end
  return count
end
syscalls.delete= function(path)
  if hostdisk_path then
    os.remove(hostdisk_path .. path)
  end
  vfs[path] = nil
end
syscalls.ps    = function()
  local list = {}
  for pid, p in pairs(procs) do
    table.insert(list, {pid=p.pid, name=p.name, state=p.state})
  end
  return list
end

local function syscall(name, ...)
  local fn = syscalls[name]
  if not fn then error("unknown syscall: " .. name) end
  return fn(...)
end

-- ── Scheduler (cooperative round-robin) ───────────────────────────────────────
local function scheduler_run()
  io.write("[Cynessa] Scheduler running\n")
  while true do
    local any = false
    for pid, p in pairs(procs) do
      if p.state == "ready" or p.state == "running" then
        any = true
        current_pid = pid
        p.state = "running"
        local ok, err = coroutine.resume(p.thread, syscall)
        if not ok then
          io.write(string.format("[Cynessa] pid=%d crashed: %s\n", pid, tostring(err)))
          proc_exit(pid, 1)
        elseif coroutine.status(p.thread) == "dead" then
          proc_exit(pid, 0)
        else
          p.state = "ready"
        end
      end
    end
    -- Clean up zombies
    for pid, p in pairs(procs) do
      if p.state == "zombie" then procs[pid] = nil end
    end
    if not any then break end
  end
  io.write("[Cynessa] All processes exited\n")
end

-- ── Init system ───────────────────────────────────────────────────────────────
local function load_proc_from_vfs(path, syscall)
  local data, err = vfs_read(path)
  if not data then return nil, err end
  local fn, lerr = load(data, path, "t", {
    syscall   = syscall,
    print     = print,
    io        = io,
    os        = os,
    arg       = args,
    args      = args,
    loadoscyn = function()
      local data, err = vfs_read("/lib/oscyn.lua")
      if not data then error("oscyn not found: "..tostring(err)) end
      local fn, lerr = load(data, "oscyn", "t", {
        syscall=syscall, string=string, table=table,
        math=math, pairs=pairs, ipairs=ipairs,
        tostring=tostring, tonumber=tonumber,
        pcall=pcall, type=type, io=io,
      })
      if not fn then error("oscyn load error: "..tostring(lerr)) end
      return fn()
    end,
    pairs     = pairs,
    ipairs    = ipairs,
    tostring  = tostring,
    tonumber  = tonumber,
    type      = type,
    error     = error,
    assert    = assert,
    pcall     = pcall,
    xpcall    = xpcall,
    select    = select,
    unpack    = table.unpack,
    rawget    = rawget,
    rawset    = rawset,
    setmetatable = setmetatable,
    getmetatable = getmetatable,
    next      = next,
    load      = load,
    string    = string,
    table     = table,
    math      = math,
    coroutine = coroutine,
  })
  if not fn then return nil, lerr end
  return fn
end

local function init(syscall)
  io.write("[init] PID 1 starting\n")

  -- Read /etc/rc.conf for service list
  local rc, err = syscall("read", "/etc/rc.conf")
  if rc then
    io.write("[init] /etc/rc.conf:\n" .. rc .. "\n")
  else
    io.write("[init] no /etc/rc.conf, continuing\n")
  end

  -- Start services listed in /etc/services
  local svc_data = syscall("read", "/etc/services")
  if svc_data then
    for svc in svc_data:gmatch("[^\n]+") do
      svc = svc:gsub("^%s*",""):gsub("%s*$","")
      if svc ~= "" and not svc:match("^#") then
        local path = "/sbin/" .. svc
        local fn = load_proc_from_vfs(path, syscall)
        if fn then
          syscall("spawn", svc, fn)
          io.write("[init] started service: " .. svc .. "\n")
        else
          io.write("[init] missing service: " .. path .. "\n")
        end
      end
    end
  end

  -- Yield to let services run first
  coroutine.yield()

  -- Start shell
  io.write("[init] starting shell\n")
  local sh_fn = load_proc_from_vfs("/bin/sh", syscall)
  if sh_fn then
    syscall("spawn", "sh", sh_fn)
  else
    io.write("[init] ERROR: /bin/sh not found\n")
  end

  io.write("[init] done\n")
end

-- ── Boot sequence ─────────────────────────────────────────────────────────────
local disk   = CYNESSA_DISK     or "cynessa.cyd"
local hostdisk = CYNESSA_HOSTDISK or (os.getenv("HOME") .. "/disk")

-- 1. Mount ramdisk
vfs_mount_disk(disk)

-- 2. Mount ~/disk as system root /
-- hostdisk_path is set here so vfs_read/write use it immediately
hostdisk_path = hostdisk
local ok_host, herr = pcall(function()
  -- Create essential dirs on host disk if missing
  os.execute("mkdir -p '" .. hostdisk .. "/bin'")
  os.execute("mkdir -p '" .. hostdisk .. "/sbin'")
  os.execute("mkdir -p '" .. hostdisk .. "/etc'")
  os.execute("mkdir -p '" .. hostdisk .. "/cynext'")
  os.execute("mkdir -p '" .. hostdisk .. "/var/log'")
  os.execute("mkdir -p '" .. hostdisk .. "/tmp'")
  io.write("[Cynessa] Host disk mounted as /: " .. hostdisk .. "\n")

  -- Seed host disk from ramdisk on first boot (only if file missing)
  io.write("[Cynessa] Seeding host disk from ramdisk...\n")
  for path, node in pairs(vfs) do
    local hp = hostdisk .. path
    -- Check if already exists on host
    local existing = io.open(hp, "rb")
    if existing then
      existing:close()
    else
      -- Create parent dir
      local dir = hp:match("^(.+)/[^/]+$")
      if dir then os.execute("mkdir -p '" .. dir .. "'") end
      -- Write ramdisk content to host
      local data = node.data
      if data then
        local f = io.open(hp, "wb")
        if f then
          f:write(data); f:close()
          io.write("[Cynessa]   seeded " .. path .. "\n")
        end
      end
    end
  end
end)
if not ok_host then
  io.write("[Cynessa] Warning: could not init host disk: " .. tostring(herr) .. "\n")
  hostdisk_path = nil
end

-- 3. Spawn init
proc_spawn("init", function(syscall) init(syscall) end)

-- 4. Run scheduler
scheduler_run()

io.write("[Cynessa] System halted.\n")
