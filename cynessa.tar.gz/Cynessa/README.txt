IEI Cynessa Microkernel
=======================

Files:
  bootloader.lua  - StarexBIOS bootloader
  cynessa.lua     - Cynessa microkernel
  mkdisk.lua      - Disk image builder
  cynessa.cyd     - Pre-built ramdisk image

Boot:
  lua bootloader.lua

Build your own disk:
  mkdir -p disk/bin disk/sbin disk/etc
  # add files to disk/
  lua mkdisk.lua disk cynessa.cyd

Shell commands:
  ls [path]         list vfs directory
  cat <path>        print file
  write <path> data write to vfs/host
  ps                list processes
  echo <text>
  clear
  exit

Host disk:
  Create ~/disk/ and it will be mounted at /mnt/disk
